﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeatherApp.Models
{
    public class WindDataModel
    {
        public DateTime DateTime;
        public double MetrePerSec;
        public double Direction;
    }
}
