﻿using System;
using Xunit;

namespace WeatherStationTests
{
    public class WeatherStationTests
    {

    }
}
